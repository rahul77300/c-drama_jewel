import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logoDataUrl } from '../assets/logo';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const activeLinkStyle = {
    color: '#a78bfa', // violet-400
  };

  return (
    <header className="bg-gray-800/80 backdrop-blur-sm sticky top-0 z-50 shadow-lg">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <img className="h-12 w-auto" src={logoDataUrl} alt="C-Drama Jewel Logo" />
            </Link>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <NavLink 
                  to="/" 
                  className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition"
                  style={({ isActive }) => isActive ? activeLinkStyle : undefined}
                  end
                >
                  Home
                </NavLink>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-4">
            <form onSubmit={handleSearchSubmit} className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                      <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                  </svg>
              </div>
              <input
                  id="search"
                  name="search"
                  className="block w-32 sm:w-40 md:w-56 pl-10 pr-3 py-2 border border-gray-600 rounded-md leading-5 bg-gray-700 text-gray-300 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-brand-purple focus:border-brand-purple sm:text-sm transition-all duration-300"
                  placeholder="Search..."
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>

            {user ? (
              <>
                <NavLink
                  to="/admin"
                  className="hidden sm:block text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition whitespace-nowrap"
                  style={({ isActive }) => isActive ? activeLinkStyle : undefined}
                >
                  Admin Panel
                </NavLink>
                <button
                  onClick={logout}
                  className="bg-brand-purple hover:bg-brand-purple-light text-white font-bold py-2 px-4 rounded-md transition"
                >
                  Logout
                </button>
              </>
            ) : (
              <Link to="/login" className="flex-shrink-0">
                <button className="bg-brand-purple hover:bg-brand-purple-light text-white font-bold py-2 px-4 rounded-md transition whitespace-nowrap">
                  Admin Login
                </button>
              </Link>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
