
import { Genre, ContentType } from './types';

export const ADMIN_EMAIL = 'contact.cdramajewel@gmail.com';

export const ALL_GENRES: Genre[] = Object.values(Genre);
export const ALL_CONTENT_TYPES: ContentType[] = Object.values(ContentType);
